/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package problema02;

/**
 *
 * @author LENOVO
 */
public class TotalApagar {
    
    // el metodo main no lo ocupo por que puede ocupar espacio solo estoy utulizando esta 
    // clase para llamar funciones
    // y sirve como las funciones pero ya tengo dos funciones entonces el metodo mein
    public static double calcularTotal(double n1 , double n2){
        //Es una funcion que se encarga de sumar los valores 
        //retornar el resultado de la suma
        double suma = n1 + n2 ;
        return suma;
        
        
    }
    
}
    

