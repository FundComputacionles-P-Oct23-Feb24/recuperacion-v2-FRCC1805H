/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package problema02;

/**
 *
 * @author LENOVO
 */
public class CalcularLibras {
    // el metodo main no lo ocupo por que puede ocupar espacio solo estoy utulizando esta 
// clase para llamar funciones
// y sirve como las funciones pero ya tengo dos funciones entonces el metodo mein
    public static double calcularCamaron(double n1,double n2) {

        // esta funcion la utilizo para calcular el costo de libras de camaron 
        // y retorno el resultado de la multiplicacion.
        double multiplicacion = n1 * n2;

        return multiplicacion;

    }

    public static double calcularBacalao(double n1,double n2) {

        // esta funcion se la utilizo para calcular el costo de libras de bacalao 
        // y retorno el resultado de la multiplicacion.    
        double multiplicacion = n1 * n2;

        return multiplicacion;

    }
}
    

