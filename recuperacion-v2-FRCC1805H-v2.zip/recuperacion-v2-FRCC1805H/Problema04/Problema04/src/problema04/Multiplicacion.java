/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package problema04;

/**
 *
 * @author LENOVO
 */
public class Multiplicacion {
           // el metodo main no lo ocupo por que puede ocupar espacio solo estoy utulizando esta 
           // clase para llamar funciones
           // y sirve como las funciones pero ya tengo dos funciones entonces el metodo mein
    public static int calcularMultiplicacion(int n1, int n2) {
        //Se realiza la operacion y se retorna el resultado de la multiplicacion
        int multiplicacion = n1 * n2;

        return multiplicacion;

    }
}
